fx_version 'cerulean'
game 'gta5'

version '2.0.0'
author 'Avn1uuu'

-- dependency
dependency 'kr_vehiclelocks'

server_scripts {
    '@mysql-async/lib/MySQL.lua',
    'server/main.lua'
}

client_scripts {
    '@RageUI_Old/RMenu.lua',
    '@RageUI_Old/menu/RageUI.lua',
    '@RageUI_Old/menu/Menu.lua',
    '@RageUI_Old/menu/MenuController.lua',
    
    '@RageUI_Old/components/Audio.lua',
    '@RageUI_Old/components/Enum.lua',
    '@RageUI_Old/components/Keys.lua',
    '@RageUI_Old/components/Rectangle.lua',
    '@RageUI_Old/components/Sprite.lua',
    '@RageUI_Old/components/Text.lua',
    '@RageUI_Old/components/Visual.lua',
    
    '@RageUI_Old/menu/elements/ItemsBadge.lua',
    '@RageUI_Old/menu/elements/ItemsColour.lua',
    '@RageUI_Old/menu/elements/PanelColour.lua',
    
    '@RageUI_Old/menu/items/UIButton.lua',
    '@RageUI_Old/menu/items/UICheckBox.lua',
    '@RageUI_Old/menu/items/UIList.lua',
    '@RageUI_Old/menu/items/UISeparator.lua',
    '@RageUI_Old/menu/items/UISlider.lua',
    '@RageUI_Old/menu/items/UISliderHeritage.lua',
    '@RageUI_Old/menu/items/UISliderProgress.lua',
    
    '@RageUI_Old/menu/panels/UIColourPanel.lua',
    '@RageUI_Old/menu/panels/UIGridPanel.lua',
    '@RageUI_Old/menu/panels/UIPercentagePanel.lua',
    '@RageUI_Old/menu/panels/UIStatisticsPanel.lua',
    
    '@RageUI_Old/menu/windows/UIHeritage.lua',
    
    'client/main.lua'
}
lua54 'yes'