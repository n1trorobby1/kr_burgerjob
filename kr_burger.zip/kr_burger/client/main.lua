ESX = nil;

CreateThread(function()
    while ESX == nil do
        TriggerEvent('esx:getSharedObject', function(obj) ESX = obj; end);
        Wait(1000);
    end

    ESX.TriggerServerCallback('edu_burger:start', function(data)
        Initialize(data);
    end)
end)


--
--- VARIABLES
--

local Menus = {};
local Deliveries = {}
local JobBlips = {};
local Blips = {};
local Working = false;
local PauseDeliveryComplete = false;
local WorkVehicleIndex = nil;

--
--- FUNCTIONS
--


function ShowHelpNotification(message)
    AddTextEntry('eduHelpNotification', message);
    BeginTextCommandDisplayHelp('eduHelpNotification');
    EndTextCommandDisplayHelp(0, false, true, -1);
end

function ShowAdvancedNotification(message, subject, header, image_type)
    AddTextEntry('eduNotification', message);
    BeginTextCommandThefeedPost('eduNotification');
    EndTextCommandThefeedPostMessagetext(image_type, image_type, false, 4, header, subject);
    EndTextCommandThefeedPostTicker(false, true);
end

function HandleDeliveries()
    CreateThread(function()
        while Working do
            Wait(0)
            if #Deliveries > 0 then
                CurrentDelivery = table.remove(Deliveries, 1);
                local DelivBlip = AddBlipForCoord(CurrentDelivery.coords.x, CurrentDelivery.coords.y, CurrentDelivery.coords.z);
                SetBlipSprite(DelivBlip, 270);
                SetBlipDisplay(DelivBlip, 4);
                SetBlipScale(DelivBlip, 0.9);
                SetBlipColour(DelivBlip, 5);
                BeginTextCommandSetBlipName('STRING');
                AddTextComponentString('Delivery');
                EndTextCommandSetBlipName(DelivBlip);
                SetBlipRoute(DelivBlip, true);

                for _, blip in pairs(Blips) do
                    RemoveBlip(blip);
                end

                Blips = {};
                Blips[#Blips + 1] = DelivBlip;
                ShowHelpNotification('A new ~g~Delivery~s~ has been ~y~marked~s~');
            else
                CurrentDelivery = nil;
                Working = false;
            end

            while CurrentDelivery do
                Wait(0);
                if CurrentDelivery ~= nil then
                    local distance = #(GetEntityCoords(PlayerPedId()) - CurrentDelivery.coords);
                    if distance > 5000.0 then
                        Wait(5000);
                    elseif distance <= 1000.0 then
                        DrawMarker(1, CurrentDelivery.coords.x, CurrentDelivery.coords.y, CurrentDelivery.coords.z - 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 4.0, 4.0, 1.0, LastJob.jobColorRGB.r, LastJob.jobColorRGB.g, LastJob.jobColorRGB.b, 100);
                        if distance <= 5.0 and IsPedInVehicle(PlayerPedId(), CurrentVehicle) and not PauseDeliveryComplete then
                            ESX.ShowHelpNotification('Press ~INPUT_CONTEXT~ to ~g~deliver~s~ the ~y~goods~s~');
                            if IsControlJustReleased(0, 51) and GetLastInputMethod(0) then
                                PlaySoundFrontend(-1, "CONFIRM_BEEP","HUD_MINI_GAME_SOUNDSET", 1)
                                PauseDeliveryComplete = true;
                                ESX.TriggerServerCallback('edu_burger:dropoff', function(message, completedShift)
                                    FreezeEntityPosition(CurrentVehicle, true);
                                    for _, blip in pairs(Blips) do
                                        RemoveBlip(blip);
                                    end

                                    Blips = {};
                                    CurrentDelivery = nil;

                                    Wait(3000);
                                    FreezeEntityPosition(CurrentVehicle, false);

                                    PauseDeliveryComplete = false;

                                    if message then
                                        ShowAdvancedNotification(message, '~g~Headquarters', LastJob.jobDisplayName, LastJob.notifyChar);
                                    end

                                    if completedShift then
                                        SetBlipRoute(JobBlips[LastJob.jobName], true);
                                        Working = false;
                                    end
                                end, CurrentDelivery, #Deliveries, LastJob);
                            end
                        end
                    end
                end
            end
        end
        for _, blip in pairs(Blips) do
            RemoveBlip(blip);
        end
        Blips = {};
    end)
end

function RegisterMenus(jobs)
    for id, data in pairs(jobs) do
        Menus[id] = RageUI.CreateMenu(string.format('%s%s', data.jobColor, data.jobDisplayName), data.jobSubtitle, 1315, 1, 'Custom_Menu_Head', 'Custom_Menu_Head')
    end

    CreateThread(function()
        while true do
            for id, data in pairs(jobs) do
                RageUI.IsVisible(Menus[id], function()
                    local CurrentGameTime = GetClockHours();
                    local HoursActive = CurrentGameTime > data.coreHours.start and CurrentGameTime < data.coreHours.finish;

                    RageUI.Button(string.format('%s%s', data.jobColor, data.jobDisplayName), MenuData.deliverLeft == 0 and string.format('~g~You are the highest rank in~s~ %s%s!', data.jobColor, data.jobDisplayName) or string.format('~y~%s~s~ deliveries left to rank up in %s%s!', MenuData.deliverLeft, data.jobColor, data.jobDisplayName), { RightLabel = string.format('Rank: %s', MenuData.jobRank) }, true, {});
                    RageUI.Button('~y~Core Hours', string.format('~y~%sx~s~ payout during these times', MenuData.coreBonus), { RightLabel = data.coreHours.display .. (HoursActive and ' (~y~Active~s~)' or '') }, true, {});

                    RageUI.List('Work Vehicles', MenuData.workVehicles, WorkVehicleIndex or 1, nil, {}, true, { 
                        onListChange = function(Index, Item)
                            WorkVehicleIndex = Index; 
                        end
                    });

                    if MenuData.jobData ~= id then
                        RageUI.Button('~g~Start Shift', nil, { RightLabel = '→→→' }, true, {
                            onSelected = function()
                                LastJob = data;

                                local foundSpawnPoint = nil;
                                for i=1, #MenuData.vehicleSpawns, 1 do
                                    i = math.random(1, #MenuData.vehicleSpawns);
                                    if ESX.Game.IsSpawnPointClear(MenuData.vehicleSpawns[i].coords, MenuData.vehicleSpawns[i].radius) then
                                        foundSpawnPoint = MenuData.vehicleSpawns[i];
                                        PlaySoundFrontend(-1, "CONFIRM_BEEP","HUD_MINI_GAME_SOUNDSET", 1)
                                        break;
                                    end
                                end

                                ESX.TriggerServerCallback('edu_burger:startShift', function(result)
                                    ShowAdvancedNotification(result.message, '~g~Headquarters', data.jobDisplayName, data.notifyChar)

                                    while not NetworkDoesEntityExistWithNetworkId(result.vehicle) do Wait(10); end
                                    local jobCar = NetToVeh(result.vehicle);

                                    CurrentVehicle = jobCar;

                                    VehicleBlip = AddBlipForEntity(jobCar);
                                    SetBlipSprite(VehicleBlip, data.vehicleBlip.sprite);
                                    SetBlipScale(VehicleBlip, 0.9);
                                    SetBlipDisplay(VehicleBlip, 5);
                                    SetBlipColour(VehicleBlip, 5);
                                    DecorSetFloat(jobCar, '_FUEL_LEVEL', 100.0);
                                    SetVehicleDoorsLocked(CurrentVehicle, 1);

                                     ESX.TriggerServerCallback('a_get_unique_plate', function(newPlate)
                                         SetVehicleNumberPlateText(jobCar, newPlate);
                                         exports.kr_vehiclelocks:NewVehicleKey(newPlate);
                                     end)


                                    Working = true
                                    Deliveries = result.deliveries;
                                    HandleDeliveries();

                                    RageUI.CloseAll();
                                end, {
                                    job = id,
                                    rank = MenuData.jobRank,
                                    vehicle = WorkVehicleIndex ~= nil and WorkVehicleIndex or 1,
                                    spawn = foundSpawnPoint,
                                    core = HoursActive
                                })
                            end
                        });
                    else
                        RageUI.Button('~o~Finish Shift', nil, {
                            RightLabel = '→→→'
                        }, true, {
                            onSelected = function()
                                RageUI.CloseAll();

                                ESX.TriggerServerCallback('edu_burger:finishShift', function(message)
                                    ShowAdvancedNotification(message, '~g~Headquarters', data.jobDisplayName, data.notifyChar);

                                    Deliveries = {};
                                    CurrentDelivery = nil;

                                    if (VehicleBlip) then
                                        RemoveBlip(VehicleBlip);
                                        VehicleBlip = nil;
                                    end

                                    for _, blip in pairs(Blips) do
                                        RemoveBlip(blip);
                                    end

                                    Blips = {};
                                    Working = false;
                                end, {
                                    job = id
                                })
                            end
                        });
                    end
                end)
            end
            Wait(5);
        end
    end)
end

function Initialize(config)
    local dataConfig = config;

    RegisterMenus(dataConfig);

    for id, data in pairs(dataConfig) do
        local CurrentGameTime = GetClockHours();

        JobBlips[id] = AddBlipForCoord(data.clockIn);
        SetBlipSprite(JobBlips[id], data.blipDetails.sprite);
        SetBlipDisplay(JobBlips[id], 4);
        SetBlipScale(JobBlips[id], 0.9);
        SetBlipColour(JobBlips[id], data.blipDetails.color);
        SetBlipAsShortRange(JobBlips[id], true);
        BeginTextCommandSetBlipName('STRING');
        AddTextComponentString(data.jobDisplayName);
        EndTextCommandSetBlipName(JobBlips[id]);
    end

    CreateThread(function()
        while true do
            Wait(1);
            local ped = PlayerPedId();
            local coords = GetEntityCoords(ped);
            local sleep = true;
            for id, data in pairs(dataConfig) do
                local distance = #(coords - data.clockIn);
                if (distance <= 50) then
                    sleep = false;
                    DrawMarker(1, data.clockIn, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 2.0, 2.0, 0.85, data.jobColorRGB.r, data.jobColorRGB.g, data.jobColorRGB.b, 100);
                    if (distance <= 2.0) then
                        ShowHelpNotification(string.format('Press ~INPUT_CONTEXT~ to work at %s%s', data.jobColor, data.jobDisplayName));
                        if IsControlJustPressed(0, 51) then
                            ESX.TriggerServerCallback('edu_burger:getMenuData', function(result)
                                MenuData = result;
                                WorkVehicleIndex = nil;

                                RageUI.Visible(Menus[id], not RageUI.Visible(Menus[id]))
                            end, id)
                        end
                    end
                end
            end
            if sleep then Wait(2300); end;
        end
    end)
end