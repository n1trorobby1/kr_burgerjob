ESX = nil 
TriggerEvent('esx:getSharedObject', function(obj) ESX = obj; end)

--
--- VARIABLES
--

local registeredPlayer = {};
local Config = {}

Config.Jobs = {
    this = {
        clockIn = vector3(-1182.68, -883.48, 12.77), -- Location
        coreHours = { start = 8, finish = 12, display = '8am - 12am' }, -- Hours with Bonus

        blipDetails = { sprite = 106, scale = 0.9, color = 5 }, -- Static Blip
        vehicleBlip = { sprite = 348, color = 1 }, -- Vehicle Blip

        jobColor = '~r~', -- Name Color
        jobColorRGB = { r = 255, g = 255, b = 0}, -- Marker Color
        jobName = 'this', -- Same Name as table index
        jobDisplayName = 'BurgerShot', -- Display Name (notification, menu, help..)
        jobSubtitle = '~y~Drop it fast', -- Menu subtitle

        notifyChar = 'CHAR_NIGEL', -- Notification Image
        waypointColor = 5 -- Minimap waypoint "route" color
    }
}

Config.Bonus = {
    this = 1.7
}

Config.Vehicles = {
    this = {
        list = { {Name = 'faggio3'} },
        spawn = {
            { coords = vector3(-1171.21, -879.94, 14.11), heading = 119.7, radius = 5},
            { coords = vector3(-1172.45, -876.69, 14.13), heading = 128.5, radius = 5},
            { coords = vector3(-1174.5, -873.32, 14.13), heading = 118.79, radius = 5},
        }
    }
}

Config.Rank = {
    this = {
        [1] = {
            price = 2500,
            left = 100
        },
        [2] = {
            price = 3350,
            left = 150
        },
        [3] = {
            price = 3800,
            left = 350
        },
        [4] = {
            price = 4000,
            left = 0 -- last rank always 0
        }
    }
}

Config.Deliveries = {
    this = {
        [1] = {
            { coords = vector3(-1024.58, -1014.46, 1.72) },
            { coords = vector3(-985.15, -984.28, 1.6) },
            { coords = vector3(-1077.5, -1018.3, 1.71) },
            { coords = vector3(-1112.1, -1056.21, 1.66) },
            { coords = vector3(-1161.64, -1096.44, 1.67) },
            { coords = vector3(-1149.26, -1156.79, 2.27) },
            { coords = vector3(-1119.72, -1226.66, 1.85) },
            { coords = vector3(-978.96, -1200.92, 4.24) },
            { coords = vector3(-854.02, -1096.4, 1.69) },
            { coords = vector3(-884.23, -1068.31, 1.69) },
            { coords = vector3(-891.73, -993.58, 1.69) },
            { coords = vector3(-921.64, -950.07, 1.69) },
            { coords = vector3(-950.18, -898.45, 1.69) },
            { coords = vector3(-1021.99, -891.58, 5.14) },
        },
        [2] = {
            { coords = vector3(-1024.58, -1014.46, 1.72) },
            { coords = vector3(-985.15, -984.28, 1.6) },
            { coords = vector3(-1077.5, -1018.3, 1.71) },
            { coords = vector3(-1112.1, -1056.21, 1.66) },
            { coords = vector3(-1161.64, -1096.44, 1.67) },
            { coords = vector3(-1149.26, -1156.79, 2.27) },
            { coords = vector3(-1119.72, -1226.66, 1.85) },
            { coords = vector3(-978.96, -1200.92, 4.24) },
            { coords = vector3(-854.02, -1096.4, 1.69) },
            { coords = vector3(-884.23, -1068.31, 1.69) },
            { coords = vector3(-891.73, -993.58, 1.69) },
            { coords = vector3(-921.64, -950.07, 1.69) },
            { coords = vector3(-950.18, -898.45, 1.69) },
            { coords = vector3(-1021.99, -891.58, 5.14) },
        },
        [3] = {
            { coords = vector3(-1322.03, -1169.2, 4.28) },
            { coords = vector3(-1312.4, -1228.86, 4.41) },
            { coords = vector3(-1306.5, -1315.18, 4.37) },
            { coords = vector3(-1261.56, -1354.29, 3.6) },
            { coords = vector3(-1131.01, -1453.56, 4.39) },
            { coords = vector3(-1107.64, -1515.65, 4.01) },
            { coords = vector3(-1085.74, -1498.08, 4.46) },
            { coords = vector3(-1080.36, -1551.0, 4.07) },
            { coords = vector3(-1048.32, -1569.88, 4.39) },
            { coords = vector3(-1040.52, -1592.48, 4.36) },
            { coords = vector3(-1117.64, -1575.08, 3.87) },
            { coords = vector3(-1153.9, -1474.96, 3.71) },
        },
        [4] = {
            { coords = vector3(-1322.03, -1169.2, 4.28) },
            { coords = vector3(-1312.4, -1228.86, 4.41) },
            { coords = vector3(-1306.5, -1315.18, 4.37) },
            { coords = vector3(-1261.56, -1354.29, 3.6) },
            { coords = vector3(-1131.01, -1453.56, 4.39) },
            { coords = vector3(-1107.64, -1515.65, 4.01) },
            { coords = vector3(-1085.74, -1498.08, 4.46) },
            { coords = vector3(-1080.36, -1551.0, 4.07) },
            { coords = vector3(-1048.32, -1569.88, 4.39) },
            { coords = vector3(-1040.52, -1592.48, 4.36) },
            { coords = vector3(-1117.64, -1575.08, 3.87) },
            { coords = vector3(-1153.9, -1474.96, 3.71) },
        },
        [5] = {
            { coords = vector3(-1322.03, -1169.2, 4.28) },
            { coords = vector3(-1312.4, -1228.86, 4.41) },
            { coords = vector3(-1306.5, -1315.18, 4.37) },
            { coords = vector3(-1261.56, -1354.29, 3.6) },
            { coords = vector3(-1131.01, -1453.56, 4.39) },
            { coords = vector3(-1107.64, -1515.65, 4.01) },
            { coords = vector3(-1085.74, -1498.08, 4.46) },
            { coords = vector3(-1080.36, -1551.0, 4.07) },
            { coords = vector3(-1048.32, -1569.88, 4.39) },
            { coords = vector3(-1040.52, -1592.48, 4.36) },
            { coords = vector3(-1117.64, -1575.08, 3.87) },
            { coords = vector3(-1153.9, -1474.96, 3.71) },
        }
    }
}

--
--- FUNCTIONS
--

function CreateRegister(data)
    local self = {};
    self.identifier = data.identifier;
    self.rank = (data.rank and json.decode(data.rank)) or {};
    self.left = (data.left and json.decode(data.left)) or {};
    self.working = false;

    self.save = function()
        MySQL.Sync.execute('UPDATE edu_burger SET `rank` = @rank, `left` = @left WHERE `identifier` = @identifier', {['@rank'] = json.encode(self.rank), ['@left'] = json.encode(self.left), ['@identifier'] = self.identifier})
    end

    return self;
end

ESX.RegisterServerCallback('edu_burger:start', function(source, cb) 
    cb(Config.Jobs);
end)

ESX.RegisterServerCallback('edu_burger:dropoff', function(source, cb, delivery, restante, data)
    if registeredPlayer[source].working and data.jobName == registeredPlayer[source].working.id then
        local ped = GetPlayerPed(source);
        local coords = GetEntityCoords(ped);
        if #(coords - delivery.coords) < 20.0 then
            if restante > 0 then
                cb('~y~ Continue with the next delivery', false);
            else
                registeredPlayer[source].working.finished = true;
                cb('~g~ You have finished! Return the company vehicle to be paid.', true);
            end
        end
    end
end)

ESX.RegisterServerCallback('edu_burger:startShift', function(source, cb, data)
    if not data.spawn then data.spawn = Config.Vehicles[data.job].spawn[1]; end;
    local vehicle = CreateVehicle(GetHashKey(Config.Vehicles[data.job].list[data.vehicle].Name), data.spawn.coords, data.spawn.heading, true, true);
    while not DoesEntityExist(vehicle) do Wait(0); end
    local netID = NetworkGetNetworkIdFromEntity(vehicle);
    SetVehicleDoorsLocked(vehicle, 0);

    registeredPlayer[source].working = { inBonus = data.core, vehicle = netID, id = data.job };

    print("Deliveries", #Config.Deliveries[data.job][data.rank]);

    cb({
        message = 'Your vehicle is waiting for you at the ~y~Burger~s~ depot, check your ~g~map',
        vehicle = netID,
        deliveries = Config.Deliveries[data.job][data.rank]
    })
end)

ESX.RegisterServerCallback('edu_burger:finishShift', function(source, cb, data)
    if registeredPlayer[source].working and data.job == registeredPlayer[source].working.id and registeredPlayer[source].working.finished then
        local xPlayer = ESX.GetPlayerFromId(source);
        local money = Config.Rank[data.job][registeredPlayer[source].rank[data.job]].price * ((registeredPlayer[source].working.inBonus and Config.Bonus[data.job]) or 1);

        registeredPlayer[source].left[data.job] = registeredPlayer[source].left[data.job] - 1;

        if registeredPlayer[source].left[data.job] - 1 == 0 then
            if Config.Rank[data.job][registeredPlayer[source].rank[data.job] + 1] then
                registeredPlayer[source].rank[data.job] = registeredPlayer[source].rank[data.job] + 1;
                registeredPlayer[source].left[data.job] = Config.Rank[data.job][registeredPlayer[source].rank[data.job]];
            end
        end


       xPlayer.addAccountMoney('money', money);
        local vehicle = NetworkGetEntityFromNetworkId(registeredPlayer[source].working.vehicle);
        DeleteEntity(vehicle);

        registeredPlayer[source].working = false;
        registeredPlayer[source].save();

        cb('You ~g~completed~s~ the shift!                                                                                  Total Pay: ~g~'..money..'~s~                                              Base Pay: ~y~'..money..'~s~                                    Core Hours Bonus:   ');
    elseif data.job == registeredPlayer[source].working.id then
        local vehicle = NetworkGetEntityFromNetworkId(registeredPlayer[source].working.vehicle);
        DeleteEntity(vehicle);
        registeredPlayer[source].working = false;
        registeredPlayer[source].save();
        
        cb('~r~An error has ocurred, you are not working or u haven\'t finished the work..');
    else
        cb('~r~You are not working for this company..');
    end
end)

ESX.RegisterServerCallback('edu_burger:getMenuData', function(source, cb, id)
    if not registeredPlayer[source] then
        local xPlayer = ESX.GetPlayerFromId(source);
        local result = MySQL.Sync.fetchAll('SELECT * FROM edu_burger WHERE identifier = @identifier', {['@identifier'] = xPlayer.identifier});
        if result[1] == nil then
            MySQL.Sync.insert('INSERT INTO edu_burger (identifier) VALUES (@identifier)', {['@identifier'] = xPlayer.identifier});
            result = MySQL.Sync.fetchAll('SELECT * FROM edu_burger WHERE identifier = @identifier', {['@identifier'] = xPlayer.identifier});
        end

        registeredPlayer[source] = CreateRegister(result[1]);
    end

    if not registeredPlayer[source].rank[id] then registeredPlayer[source].rank[id] = 1; end
    if not registeredPlayer[source].left[id] then registeredPlayer[source].left[id] = Config.Rank[id][registeredPlayer[source].rank[id]].left; end

    registeredPlayer[source].save();

    cb({
        deliverLeft = registeredPlayer[source].left[id],
        jobRank = registeredPlayer[source].rank[id],
        coreBonus = Config.Bonus[id],
        defaultVehicle = Config.Vehicles[id].default,
        workVehicles = Config.Vehicles[id].list,
        jobData = (registeredPlayer[source].working and id) or 'none',
        vehicleSpawns = Config.Vehicles[id].spawn
    });

end)