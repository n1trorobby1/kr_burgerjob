CREATE TABLE `edu_burger` (
	`identifier` VARCHAR(200) NOT NULL COLLATE 'utf8mb4_general_ci',
	`left` LONGTEXT NULL DEFAULT '[]' COLLATE 'utf8mb4_bin',
	`rank` LONGTEXT NULL DEFAULT '[]' COLLATE 'utf8mb4_bin',
	PRIMARY KEY (`identifier`) USING BTREE,
	CONSTRAINT `left` CHECK (json_valid(`left`)),
	CONSTRAINT `rank` CHECK (json_valid(`rank`))
)
COLLATE='utf8mb4_general_ci'
ENGINE=InnoDB
;
